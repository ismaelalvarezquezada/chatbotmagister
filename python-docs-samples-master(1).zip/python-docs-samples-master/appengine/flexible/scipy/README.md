# SciPy on App Engine Flexible

This sample demonstrates how to use SciPy to resize an image on App Engine Flexible.

