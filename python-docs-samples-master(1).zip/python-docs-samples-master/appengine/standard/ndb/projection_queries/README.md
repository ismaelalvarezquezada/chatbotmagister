## App Engine Datastore NDB Projection Queries Samples

This contains snippets used in the NDB projection queries documentation,
demonstrating various ways to make ndb projection queries.

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/appengine/docs/python/datastore/projectionqueries

<!-- end-auto-doc-link -->
