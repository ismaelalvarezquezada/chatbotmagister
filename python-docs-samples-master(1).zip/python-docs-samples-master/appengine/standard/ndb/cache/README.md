## App Engine Datastore NDB Cache Samples

This contains snippets used in the NDB cache documentation, demonstrating
various operations on ndb caches.

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/appengine/docs/python/ndb/cache

<!-- end-auto-doc-link -->
