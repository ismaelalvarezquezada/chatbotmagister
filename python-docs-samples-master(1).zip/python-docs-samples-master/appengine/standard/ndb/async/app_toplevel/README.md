This is in a separate folder to isolate it from the other apps.
This is necessary because the test won't pass when run with the other tests.
